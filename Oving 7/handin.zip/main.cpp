#include "std_lib_facilities.h"
#include "Animal.h"

/*
int main()
{
	testAnimal();
}
*/