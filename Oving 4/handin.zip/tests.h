#pragma once

void testString();